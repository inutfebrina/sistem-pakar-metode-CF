﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","lt",{button:"Įterpkite kodo gabaliuką",codeContents:"Kodo turinys",emptySnippetError:"Kodo fragmentas negali būti tusčias.",language:"Kalba",title:"Kodo fragmentas",pathName:"kodo fragmentas"});